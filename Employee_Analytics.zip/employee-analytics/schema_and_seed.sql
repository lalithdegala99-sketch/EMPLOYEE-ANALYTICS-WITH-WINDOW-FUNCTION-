-- ===========================================================================
-- Employee Analytics Using SQL Window Functions
-- Schema + seed data
-- Portable across PostgreSQL / MySQL 8+ / SQLite (all support standard
-- window function syntax used below: RANK, DENSE_RANK, LAG, LEAD, NTILE,
-- PERCENT_RANK).
-- ===========================================================================

CREATE TABLE departments (
    department_id   INTEGER PRIMARY KEY,
    department_name TEXT NOT NULL
);

CREATE TABLE employees (
    employee_id     INTEGER PRIMARY KEY,
    full_name       TEXT NOT NULL,
    department_id   INTEGER NOT NULL,
    job_title       TEXT NOT NULL,
    hire_date       DATE NOT NULL,
    salary          NUMERIC(10, 2) NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

INSERT INTO departments (department_id, department_name) VALUES
 (1, 'Engineering'),
 (2, 'Sales'),
 (3, 'Marketing'),
 (4, 'Human Resources'),
 (5, 'Finance');

INSERT INTO employees (employee_id, full_name, department_id, job_title, hire_date, salary) VALUES
 (1,  'Arjun Mehta',      1, 'Software Engineer',    '2021-03-14', 62000),
 (2,  'Sneha Kapoor',     1, 'Senior Engineer',       '2019-06-01', 91000),
 (3,  'Rahul Verma',      1, 'Engineering Manager',   '2017-01-10', 118000),
 (4,  'Divya Nair',       1, 'Software Engineer',     '2022-08-22', 58000),
 (5,  'Karan Singh',      1, 'Senior Engineer',       '2020-02-17', 88000),
 (6,  'Priya Sharma',     2, 'Sales Executive',       '2020-11-05', 48000),
 (7,  'Vikram Rao',       2, 'Sales Manager',         '2016-04-19', 95000),
 (8,  'Anjali Gupta',     2, 'Sales Executive',       '2023-01-09', 45000),
 (9,  'Rohan Joshi',      2, 'Senior Sales Executive','2018-09-30', 67000),
 (10, 'Meera Iyer',       3, 'Marketing Specialist',  '2021-07-12', 54000),
 (11, 'Aditya Kumar',     3, 'Marketing Manager',     '2015-12-01', 99000),
 (12, 'Neha Reddy',       3, 'Marketing Specialist',  '2022-05-18', 52000),
 (13, 'Suresh Pillai',    4, 'HR Executive',          '2019-10-08', 51000),
 (14, 'Kavya Menon',      4, 'HR Manager',            '2014-03-25', 87000),
 (15, 'Amit Desai',       5, 'Financial Analyst',     '2020-06-15', 64000),
 (16, 'Pooja Bhatt',      5, 'Finance Manager',       '2016-08-02', 102000),
 (17, 'Sanjay Malhotra',  5, 'Financial Analyst',     '2023-02-27', 56000),
 (18, 'Ishita Chopra',    1, 'Software Engineer',     '2023-09-11', 59000),
 (19, 'Manish Trivedi',   2, 'Sales Executive',       '2021-12-03', 47000),
 (20, 'Ritu Bansal',      3, 'Marketing Specialist',  '2020-04-28', 53000);
