-- ===========================================================================
-- Employee Analytics Using SQL Window Functions
-- Analytical queries: salary benchmarking, hiring trends, departmental
-- rankings, and headcount metrics. Uses RANK, DENSE_RANK, LAG, LEAD,
-- NTILE, and PERCENT_RANK.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. Salary rank within each department (RANK vs DENSE_RANK)
--    RANK leaves gaps after ties; DENSE_RANK does not. Shown side by side
--    to benchmark where each employee stands against department peers.
-- ---------------------------------------------------------------------------
SELECT
    d.department_name,
    e.full_name,
    e.job_title,
    e.salary,
    RANK()       OVER (PARTITION BY e.department_id ORDER BY e.salary DESC) AS salary_rank,
    DENSE_RANK() OVER (PARTITION BY e.department_id ORDER BY e.salary DESC) AS salary_dense_rank
FROM employees e
JOIN departments d ON d.department_id = e.department_id
ORDER BY d.department_name, salary_rank;


-- ---------------------------------------------------------------------------
-- 2. Salary gap to the next-highest and next-lowest paid peer in the same
--    department (LAG / LEAD), ordered by salary. Useful for spotting pay
--    compression or unusually large gaps between adjacent salary bands.
-- ---------------------------------------------------------------------------
SELECT
    d.department_name,
    e.full_name,
    e.salary,
    LAG(e.salary)  OVER (PARTITION BY e.department_id ORDER BY e.salary) AS next_lower_salary,
    e.salary - LAG(e.salary) OVER (PARTITION BY e.department_id ORDER BY e.salary) AS gap_to_lower,
    LEAD(e.salary) OVER (PARTITION BY e.department_id ORDER BY e.salary) AS next_higher_salary,
    LEAD(e.salary) OVER (PARTITION BY e.department_id ORDER BY e.salary) - e.salary AS gap_to_higher
FROM employees e
JOIN departments d ON d.department_id = e.department_id
ORDER BY d.department_name, e.salary;


-- ---------------------------------------------------------------------------
-- 3. Hiring trend: for each department, compare each hire's date to the
--    previous hire's date (LAG) to see the gap in days between hires,
--    surfacing hiring pace/slowdowns over time.
-- ---------------------------------------------------------------------------
SELECT
    d.department_name,
    e.full_name,
    e.hire_date,
    LAG(e.hire_date) OVER (PARTITION BY e.department_id ORDER BY e.hire_date) AS previous_hire_date,
    CAST(julianday(e.hire_date) - julianday(
        LAG(e.hire_date) OVER (PARTITION BY e.department_id ORDER BY e.hire_date)
    ) AS INTEGER) AS days_since_previous_hire
FROM employees e
JOIN departments d ON d.department_id = e.department_id
ORDER BY d.department_name, e.hire_date;


-- ---------------------------------------------------------------------------
-- 4. Company-wide salary quartiles (NTILE) — splits all employees into 4
--    roughly equal-sized salary bands, independent of department, for
--    compensation-band benchmarking.
-- ---------------------------------------------------------------------------
SELECT
    full_name,
    job_title,
    salary,
    NTILE(4) OVER (ORDER BY salary DESC) AS salary_quartile
FROM employees
ORDER BY salary DESC;


-- ---------------------------------------------------------------------------
-- 5. Percentile standing (PERCENT_RANK) — where each employee's salary
--    sits relative to the entire company, as a 0-1 percentile.
-- ---------------------------------------------------------------------------
SELECT
    full_name,
    department_id,
    salary,
    ROUND(PERCENT_RANK() OVER (ORDER BY salary), 3) AS salary_percentile
FROM employees
ORDER BY salary_percentile DESC;


-- ---------------------------------------------------------------------------
-- 6. Departmental headcount and average-salary ranking — aggregates each
--    department, then ranks departments against each other.
-- ---------------------------------------------------------------------------
SELECT
    d.department_name,
    COUNT(*)                       AS headcount,
    ROUND(AVG(e.salary), 2)        AS avg_salary,
    RANK() OVER (ORDER BY AVG(e.salary) DESC) AS avg_salary_rank,
    RANK() OVER (ORDER BY COUNT(*) DESC)      AS headcount_rank
FROM employees e
JOIN departments d ON d.department_id = e.department_id
GROUP BY d.department_name
ORDER BY avg_salary_rank;


-- ---------------------------------------------------------------------------
-- 7. Hiring trend by year — yearly headcount growth, with year-over-year
--    change via LAG on the aggregated yearly counts.
-- ---------------------------------------------------------------------------
WITH yearly_hires AS (
    SELECT
        CAST(strftime('%Y', hire_date) AS INTEGER) AS hire_year,
        COUNT(*) AS hires_that_year
    FROM employees
    GROUP BY hire_year
)
SELECT
    hire_year,
    hires_that_year,
    LAG(hires_that_year) OVER (ORDER BY hire_year) AS hires_previous_year,
    hires_that_year - LAG(hires_that_year) OVER (ORDER BY hire_year) AS yoy_change
FROM yearly_hires
ORDER BY hire_year;


-- ---------------------------------------------------------------------------
-- 8. Top earner per department (RANK = 1 filter via CTE, since window
--    functions cannot be used directly in WHERE).
-- ---------------------------------------------------------------------------
WITH ranked AS (
    SELECT
        d.department_name,
        e.full_name,
        e.salary,
        RANK() OVER (PARTITION BY e.department_id ORDER BY e.salary DESC) AS r
    FROM employees e
    JOIN departments d ON d.department_id = e.department_id
)
SELECT department_name, full_name, salary
FROM ranked
WHERE r = 1
ORDER BY department_name;
