"""
Runs schema_and_seed.sql and analytics_queries.sql against an in-memory
SQLite database and prints every query's results. No server setup needed —
this is a reproducible way to verify the analytics queries actually work.
"""

import sqlite3
import os

BASE = os.path.dirname(__file__)

TITLES = [
    "1. Salary rank within department (RANK vs DENSE_RANK)",
    "2. Salary gap to adjacent peers (LAG / LEAD)",
    "3. Hiring pace: days since previous hire in department (LAG)",
    "4. Company-wide salary quartiles (NTILE)",
    "5. Salary percentile across the company (PERCENT_RANK)",
    "6. Departmental headcount and avg-salary ranking",
    "7. Year-over-year hiring trend (LAG on yearly counts)",
    "8. Top earner per department (RANK = 1 via CTE)",
]


def split_statements(sql_text):
    statements, current = [], []
    for line in sql_text.split("\n"):
        current.append(line)
        stripped = line.strip()
        if stripped.endswith(";") and not stripped.startswith("--"):
            statements.append("\n".join(current))
            current = []
    return [s.strip() for s in statements if s.strip()]


def main():
    conn = sqlite3.connect(":memory:")

    with open(os.path.join(BASE, "schema_and_seed.sql")) as f:
        conn.executescript(f.read())

    with open(os.path.join(BASE, "analytics_queries.sql")) as f:
        queries = split_statements(f.read())

    for title, query in zip(TITLES, queries):
        print("=" * 78)
        print(title)
        print("=" * 78)
        cur = conn.execute(query)
        cols = [d[0] for d in cur.description]
        print(" | ".join(cols))
        for row in cur.fetchall():
            print(" | ".join(str(v) for v in row))
        print()


if __name__ == "__main__":
    main()
