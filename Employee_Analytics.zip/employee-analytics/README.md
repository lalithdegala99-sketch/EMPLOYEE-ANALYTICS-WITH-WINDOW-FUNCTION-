# Employee Analytics Using SQL Window Functions

An analytics system built entirely in SQL, using window functions
(`RANK`, `DENSE_RANK`, `LAG`, `LEAD`, `NTILE`, `PERCENT_RANK`) to benchmark
salaries and hiring trends across a 20-employee, 5-department dataset.

## Files

- `schema_and_seed.sql` — table definitions (`departments`, `employees`) and
  20 rows of realistic seed data across 5 departments.
- `analytics_queries.sql` — 8 analytical queries, described below.
- `run_demo.py` — runs the schema + queries against an in-memory SQLite
  database and prints the results, so the whole thing is reproducible with
  no server setup.

## Queries included

1. **Salary rank within department** (`RANK`, `DENSE_RANK`) — benchmarks
   each employee against department peers, side by side to show how ties
   are handled differently by each function.
2. **Salary gap to adjacent peers** (`LAG`, `LEAD`) — the pay difference to
   the next-lower and next-higher paid colleague in the same department,
   useful for spotting pay compression.
3. **Hiring pace** (`LAG` on hire dates) — days elapsed since the previous
   hire in the same department.
4. **Company-wide salary quartiles** (`NTILE(4)`) — splits all 20 employees
   into 4 compensation bands.
5. **Salary percentile** (`PERCENT_RANK`) — each employee's standing as a
   0–1 percentile across the whole company.
6. **Departmental rankings** — headcount and average salary per department,
   each ranked against the others with `RANK() OVER (ORDER BY ...)`.
7. **Year-over-year hiring trend** — yearly hire counts with `LAG` to show
   the change from the previous year.
8. **Top earner per department** — `RANK() = 1` filtered via a CTE (window
   functions can't be referenced directly in `WHERE`).

## Portability note

Written in standard ANSI SQL window-function syntax, so `RANK`, `DENSE_RANK`,
`LAG`, `LEAD`, `NTILE`, and `PERCENT_RANK` work unchanged on PostgreSQL,
MySQL 8+, and SQLite. Two date functions are SQLite-specific and need a
one-line swap on other engines:

| SQLite (used here) | PostgreSQL equivalent | MySQL 8+ equivalent |
|---|---|---|
| `julianday(a) - julianday(b)` | `a - b` (date subtraction) | `DATEDIFF(a, b)` |
| `strftime('%Y', hire_date)` | `EXTRACT(YEAR FROM hire_date)` | `YEAR(hire_date)` |

## Running the demo

```bash
python run_demo.py
```

This loads the schema and seed data into an in-memory SQLite database, runs
all 8 queries, and prints the results — verified output is in
`sample_output.txt`.

To run against PostgreSQL or MySQL instead, apply the two substitutions
above to query #3 and #7 in `analytics_queries.sql`, then run the file
directly with `psql` or the `mysql` CLI.
